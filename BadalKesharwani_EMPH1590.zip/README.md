# Maverick
Simple Angular 9 App
